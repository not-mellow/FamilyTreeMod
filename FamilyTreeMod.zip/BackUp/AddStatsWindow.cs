using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using ReflectionUtility;
using HarmonyLib;
using System.Threading.Tasks;

namespace FamilyTreeMod
{
    class AddStatsWindow : MonoBehaviour
    {
        public static void init()
        {
            initUIStats();
        }

        private static void initUIStats()
        {
            return;
        }
    }
}